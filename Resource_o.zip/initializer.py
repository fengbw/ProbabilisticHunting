import numpy as np
import random

Target_not_found_given_Target_in_cell_map = {}
Target_not_found_given_Target_in_cell_map[0] = 0.1
Target_not_found_given_Target_in_cell_map[1] = 0.3
Target_not_found_given_Target_in_cell_map[2] = 0.7
Target_not_found_given_Target_in_cell_map[3] = 0.9

Target_found_given_Target_in_cell_map = {}
Target_found_given_Target_in_cell_map[0] = 0.9
Target_found_given_Target_in_cell_map[1] = 0.7
Target_found_given_Target_in_cell_map[2] = 0.3
Target_found_given_Target_in_cell_map[3] = 0.1

def generate_board(dim):
    m = np.zeros([dim, dim],dtype=int)
    for i in range(dim):
        for j in range(dim):
            m[i,j] = get_surface()
    return m

def get_surface():
    p = np.random.rand()
    if p <= 0.2:
        return 0
    if p <= 0.5:
        return 1
    if p <= 0.8:
        return 2
    if p <= 1.0:
        return 3

def Target_not_found_given_Target_in_cell(cell_type):
    return Target_not_found_given_Target_in_cell_map[cell_type]

def Target_of_Type(board, type):
    dim = len(board)
    a = random.randint(0, dim-1)
    b = random.randint(0, dim-1)
    while board[a, b] != type:
        a = random.randint(0, dim - 1)
        b = random.randint(0, dim - 1)
    return (a, b)

def mod(x):
    if x >= 0:
        return x
    else:
        return -x

def ManhattanDistance(x1,y1,x2,y2):
    return mod(x1-x2) + mod(y1-y2)

def get_dis(dim,i,j):
    dis_mat = np.zeros([dim, dim])
    for l in range(dim):
        for m in range(dim):
            dis_mat[l,m] = ManhattanDistance(l, m, i, j)
    return dis_mat

def generate_intial_belief_matrix(dim):
    matrix = np.zeros([dim, dim]) + (1/(dim*dim))
    return matrix

def choose_target(dim):
    pos = np.random.randint(1, dim*dim)
    i = pos%dim
    j = int(pos/dim)%dim
    return (i, j)

def update_belief_matrix(board,belief,i,j):
    belief[i, j] = belief[i, j]*(Target_not_found_given_Target_in_cell(board[i, j]))
    normalization = np.sum(belief)
    belief = belief/normalization
    return belief

def get_prob_found_matrix(board,belief):
    dim = len(board)
    prob_found_matrix = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            prob_found_matrix[i, j] = belief[i, j]*Target_found_given_Target_in_cell_map[board[i, j]]
    return prob_found_matrix
