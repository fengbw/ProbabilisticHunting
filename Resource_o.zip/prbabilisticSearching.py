import numpy as np
import random
from numpy import unravel_index
import copy
from initializer import generate_board, Target_not_found_given_Target_in_cell, generate_intial_belief_matrix, choose_target, get_prob_found_matrix, update_belief_matrix, ManhattanDistance, Target_of_Type, get_dis

def get_max_index(prob_mat):
    max_value = np.ndarray.max(prob_mat)
    l = []
    for i in range(len(prob_mat)):
        for j in range(len(prob_mat)):
            if prob_mat[i,j] == max_value:
                l.append((i, j))
    a = random.randint(1,len(l))-1
    return l[a]

def rule_1(board,belief_matrix_,target):
    num_searches = 0
    next_step = get_max_index(belief_matrix)
    while (target[0], target[1]) != next_step:
        belief_matrix_ = update_belief_matrix(board=board, belief=belief_matrix, i=next_step[0], j=next_step[1])
        num_searches+=1
        next_step = get_max_index(belief_matrix)
    return num_searches


def rule_2(board, belief_matrix_, target):
    num_searches = 0
    prob_found_matrix_ = get_prob_found_matrix(board=board, belief=belief_matrix)
    next_step = get_max_index(prob_found_matrix)
    while (target[0], target[1]) != next_step:
        belief_matrix = update_belief_matrix(board=board, belief=belief_matrix, i = next_step[0], j = next_step[1])
        num_searches += 1
        prob_found_matrix = get_prob_found_matrix(board=board, belief=belief_matrix)
        next_step = get_max_index(prob_found_matrix)
    return num_searches

def ques_3():
    for type in [0, 1, 2, 3]:
        searches_rule_1 = 0
        searches_rule_2 = 0
        iterations = 100
        dim = 50

        for i in range(iterations):
            if i%10 == 0:
                print(i)
            board = generate_board(dim)
            target = Target_of_Type(copy.deepcopy(board), type)
            belief_matrix = generate_intial_belief_matrix(dim)
            searches_rule_1 += rule_1(copy.deepcopy(board), copy.deepcopy(belief_matrix), copy.copy(target))
            searches_rule_2 += rule_2(copy.deepcopy(board), copy.deepcopy(belief_matrix), copy.copy(target))
        print("type :: " + str(type))
        print("Average number of searches rule-1 and rule-2 respectively: ", str(searches_rule_1/iterations) + "  ,  "+str(searches_rule_2/iterations) + "\n")

def rule_1_dis(board, belief_matrix, target, simple = True):
    num_searches = 0
    next_step = get_max_index(belief_matrix_)
    dim = len(board)
    dis_matrix = np.zeros_like(board)
    while (target[0],target[1]) != next_step:
        belief_matrix = update_belief_matrix(board=board, belief=belief_matrix, i=next_step[0], j=next_step[1])
        num_searches += dis_matrix[next_step[0], next_step[1]]
        dis_matrix = get_dis(dim,i=next_step[0], j=next_step[1])
        if simple == False:
            log_dis_matrix = 1 + np.log(1 + dis_matrix)
            next_step = get_max_index(belief_matrix / log_dis_matrix)
        else:
            next_step = get_max_index(belief_matrix)
    return num_searches

def rule_2_dis(board, belief_matrix, target, simple = True):
    num_searches = 0
    prob_found_matrix = get_prob_found_matrix(board=board, belief=belief_matrix)
    next_step = get_max_index(prob_found_matrix)
    dim = len(board)
    dis_matrix = np.zeros_like(board)
    while (target[0], target[1]) != next_step:
        belief_matrix = update_belief_matrix(board=board, belief=belief_matrix, i = next_step[0], j = next_step[1])
        num_searches += dis_matrix[next_step[0], next_step[1]]
        prob_found_matrix = get_prob_found_matrix(board=board, belief=belief_matrix)
        dis_matrix = get_dis(dim, i=next_step[0], j=next_step[1])
        log_dis_matrix = 1 + np.log(1 + dis_matrix)
        if simple == False:
            next_step = get_max_index(prob_found_matrix / log_dis_matrix)
        else:
            next_step = get_max_index(prob_found_matrix_)
    return num_searches

def ques_4(board, belief_matrix, target):
    num_searches = 0
    prob_found_matrix = get_prob_found_matrix(board=board, belief=belief_matrix)
    next_step = get_max_index(prob_found_matrix_)
    while target != next_step:
        belief_matrix_ = update_belief_matrix(board=board, belief=belief_matrix, i=next_step[0], j=next_step[1])
        num_searches += 1
        prob_found_matrix_ = get_prob_found_matrix(board=board, belief=belief_matrix)
        next_step = get_max_index(prob_found_matrix_)
    return num_searches

def ques_4():
    for type in [0, 1, 2, 3]:
        searches_rule_1 = 0
        searches_rule_2 = 0
        searches_rule_1_ = 0
        searches_rule_2_ = 0
        iterations = 10
        dim = 50
        for i in range(iterations):
            if i%10 == 0:
                print(i)
            board = generate_board(dim)
            target = Target_of_Type(copy.deepcopy(board),type)
            belief_matrix = generate_intial_belief_matrix(dim)
            searches_rule_1 += rule_1_dis(copy.deepcopy(board),copy.deepcopy(belief_matrix),copy.copy(target),simple=False)
            searches_rule_1_ += rule_1_dis(copy.deepcopy(board), copy.deepcopy(belief_matrix), copy.copy(target),
                                          simple=True)
            searches_rule_2 += rule_2_dis(copy.deepcopy(board),copy.deepcopy(belief_matrix),copy.copy(target),simple=False)
            searches_rule_2_ += rule_2_dis(copy.deepcopy(board), copy.deepcopy(belief_matrix), copy.copy(target),
                                          simple=True)
        print("type :: " + str(type))
        print("Average number of searches rule-1 and rule-2 respectively: ",str(searches_rule_1/iterations)+"  ,  "+str(searches_rule_2/iterations)+"\n")
        print("Average number of searches rule-1 and rule-2 respectively: ",
              str(searches_rule_1_ / iterations) + "  ,  " + str(searches_rule_2_ / iterations) + "\n")

def move_target(dim, target, board):
    a = target[0]
    b = target[1]
    type1 = board[a, b]
    L = []
    new_L = []
    L.append([a - 1, b])
    L.append([a + 1, b])
    L.append([a, b - 1])
    L.append([a, b + 1])
    for l in L:
        if IsvalidPoint(dim, l[0], l[1]):
            new_L.append(l)
    pick = random.randint(1, len(new_L)) - 1
    type2 = board[new_L[pick][0], new_L[pick][1]]
    return new_L[pick],(type1, type2)

def get_neighbs(dim, a, b):
    L = []
    new_L = []
    L.append([a - 1, b])
    L.append([a + 1, b])
    L.append([a, b - 1])
    L.append([a, b + 1])
    for l in L:
        if IsvalidPoint(dim, l[0], l[1]):
            new_L.append(l)
    return new_L

def IsvalidPoint(dim,m,n):
    if  m < 0 or n < 0 or m >= dim or n >= dim :
        return False
    return True

def update_found_matrix_by_evidence(board, prob_found_matrix, evidence):
    type1,type2 = evidence, evidence
    for i in range(len(board)):
        for j in range(len(board)):
            if board[i,j] == type1 or board[i,j] == type2:
                prob_found_matrix_[i, j] = 0
            else:
                prob_found_matrix_[i, j] = 0
    return prob_found_matrix_

def list_contains_type(board, l, type):
    for i, j in l:
        if board[i, j] == type:
            return True
    return False

def neigh_sum(matrix):
    dim = len(matrix)
    sum_matrix = np.zeros_like(matrix)
    for i in range(dim):
        for j in range(dim):
            if i > 0 and j >0 and i < dim-1 and j < dim -1 :
                sum_matrix[i, j] = matrix[i-1, j] + matrix[i, j-1] + matrix[i+1, j] + matrix[i, j+1]
            elif i==0 and j==0:
                sum_matrix[i, j] = matrix[i + 1, j] + matrix[i, j + 1]
            elif i==dim-1 and j == dim -1:
                sum_matrix[i, j] = matrix[i-1, j] + matrix[i, j-1]
            elif i==0 and j == dim -1:
                sum_matrix[i, j] =  matrix[i, j-1] + matrix[i+1, j]
            elif i==dim-1 and j == 0:
                sum_matrix[i, j] = matrix[i-1, j]  + matrix[i, j+1]
            elif i == 0:
                sum_matrix[i, j] = matrix[i, j-1] + matrix[i+1, j] + matrix[i, j+1]
            elif i == dim-1:
                sum_matrix[i, j] = matrix[i-1, j] + matrix[i, j-1] + matrix[i, j+1]
            elif j == 0:
                sum_matrix[i, j] = matrix[i-1, j] + matrix[i+1, j] + matrix[i, j+1]
            elif j == dim-1:
                sum_matrix[i, j] = matrix[i-1, j] + matrix[i, j-1] + matrix[i+1, j]
    return sum_matrix


def update_belief_matrix_by_evidence(board, prob_found_matrix, evidence):
    type1,type2 = evidence, evidencr
    new_prob_found_matrix = np.zeros_like(prob_found_matrix)
    for i in range(len(board)):
        for j in range(len(board)):
            current_type = board[i, j]
            if current_type == type1:
                l = get_neighbs(dim=len(board), a=i, b=j)
                if list_contains_type(board, l, type2):
                    new_prob_found_matrix[i,j] = 1

            elif current_type == type2:
                l = get_neighbs(dim=len(board), a=i, b=j)
                list_contains_type(board, l, type2)
                if list_contains_type(board, l, type2):
                    new_prob_found_matrix[i, j] = 1
            else:
                new_prob_found_matrix[i, j] = 0
    sum_matrix = neigh_sum(new_prob_found_matrix)
    a = prob_found_matrix_*new_prob_found_matrix
    b = np.zeros_like(a)
    for i in range(len(a)):
        for j in range(len(a)):
            if sum_matrix[i, j] > 0.0:
                b[i, j] = a[i, j] / sum_matrix[i, j]
    f = neigh_sum(b)
    return f

def target_move_rule_1(board, belief_matrix, target):
    num_searches = 0
    dim = len(board)
    prob_found_matrix = get_prob_found_matrix(board=board, belief=belief_matrix)
    next_step = get_max_index(prob_found_matrix)

    while (target[0],target[1]) != next_step:
        belief_matrix = update_belief_matrix(board=board, belief=belief_matrix, i=next_step[0], j=next_step[1])
        num_searches += 1
        target,evidence = move_target(dim,target,board)
        prob_belief_matrix = update_belief_matrix_by_evidence(board, prob_found_matrix, evidence)
        next_step = get_max_index(prob_belief_matrix)
    return num_searches

def target_move_rule_2(board, belief_matrix, target):
    num_searches = 0
    dim = len(board)
    prob_found_matrix = get_prob_found_matrix(board=board, belief=belief_matrix)
    next_step = get_max_index(prob_found_matrix)
    while (target[0], target[1]) != next_step:
        belief_matrix = update_belief_matrix(board=board, belief=belief_matrix, i=next_step[0], j=next_step[1])
        num_searches += 1
        prob_found_matrix = get_prob_found_matrix(board=board, belief=belief_matrix)
        target,evidence = move_target(dim,target,board)
        prob_found_matrix = update_found_matrix_by_evidence(board, prob_found_matrix, evidence)
        next_step = get_max_index(prob_found_matrix)
    return num_searches

def target_move_do():
    for type in [0, 1, 2, 3]:
        searches_rule_1 = 0
        searches_rule_2 = 0
        iterations = 100
        dim = 50
        for i in range(iterations):
            if i%10 == 0:
                print(i)
            board = generate_board(dim)
            target = Target_of_Type(copy.deepcopy(board), type)
            belief_matrix = generate_intial_belief_matrix(dim)
            searches_rule_1 += part2_rule_1(copy.deepcopy(board),copy.deepcopy(belief_matrix),copy.copy(target))
            searches_rule_2 += part2_rule_2(copy.deepcopy(board),copy.deepcopy(belief_matrix),copy.copy(target))
        print("type :: " + str(type))
        print("Average number of searches rule-1 and rule-2 respectively: ",str(searches_rule_1 / iterations)+"  ,  "+str(searches_rule_2 / iterations)+"\n")
